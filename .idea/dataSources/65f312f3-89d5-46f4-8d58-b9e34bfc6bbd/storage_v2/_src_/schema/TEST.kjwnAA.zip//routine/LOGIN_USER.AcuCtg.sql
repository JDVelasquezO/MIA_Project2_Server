create PROCEDURE login_user (
    v_cursor OUT SYS_REFCURSOR,
    v_username IN VARCHAR2,
    v_password IN VARCHAR2
) AS
    BEGIN
       OPEN v_cursor FOR SELECT ID_USER FROM USERS
           WHERE USERNAME = v_username AND PASSWORD = v_password;
    END;
/

