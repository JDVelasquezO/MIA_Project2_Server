create PROCEDURE aumentarPrecioValor (nombre IN VARCHAR2, valorIncremento IN NUMBER DEFAULT 10)
IS
BEGIN
    UPDATE LIBROS SET PRECIO = PRECIO + (PRECIO * (valorIncremento)/100 )
    WHERE EDITORIAL = nombre;
END;
/

