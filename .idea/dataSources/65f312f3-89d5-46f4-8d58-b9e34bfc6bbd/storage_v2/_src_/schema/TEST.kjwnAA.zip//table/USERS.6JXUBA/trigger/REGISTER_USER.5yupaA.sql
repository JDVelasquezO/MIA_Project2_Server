create trigger REGISTER_USER
    before insert
    on USERS
    for each row
BEGIN
        /* Verificacion de correo electronico */
        IF NOT REGEXP_LIKE(:NEW.EMAIL, '[A-Za-z0-9]*@[A-Za-z]*mail.com') THEN
            RAISE_APPLICATION_ERROR(1, 'EL correo no tiene el formato correcto');
        END IF;

        /* Verificacion de username existente */
        FOR ROW IN ( SELECT USERNAME FROM USERS ) LOOP
            IF ((ROW.USERNAME = :NEW.USERNAME) ) THEN
                RAISE_APPLICATION_ERROR(2, 'EL usuario ya existe');
            END IF;
        END LOOP;

                /* Verificacion de edad */
        IF ( TO_CHAR( :NEW.DATE_BIRTH, 'YYYY') >= '2003' ) THEN
            RAISE_APPLICATION_ERROR(3, 'Eres menor de edad');
        END IF;

        IF ( (LENGTH(:NEW.PASSWORD) < 8) OR
              ( LENGTH(TRIM(TRANSLATE(:NEW.PASSWORD,
                  'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-.0123456789',
                  ''))) IS NOT NULL )
            ) THEN
                RAISE_APPLICATION_ERROR(4, 'Contraseña Inválida');
        END IF;
    END;
/

