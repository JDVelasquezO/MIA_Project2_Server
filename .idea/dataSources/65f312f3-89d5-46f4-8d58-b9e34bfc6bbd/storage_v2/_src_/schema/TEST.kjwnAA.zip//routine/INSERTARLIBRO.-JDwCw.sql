create PROCEDURE
    insertarLibro (v_titulo IN VARCHAR2, v_autor IN VARCHAR2, v_editorial IN VARCHAR2, v_precio IN NUMBER)
IS
BEGIN
    INSERT INTO LIBROS (TITULO, AUTOR, EDITORIAL, PRECIO)
    VALUES (v_titulo, v_autor, v_editorial, v_precio);
END;
/

